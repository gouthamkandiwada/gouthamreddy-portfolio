# Goutham Reddy Kandivada — Portfolio

A responsive, single-page developer portfolio built with HTML5, CSS3 and vanilla JavaScript.

## Run locally
1. Extract the project.
2. Open `index.html` in your browser. For a local server, use the VS Code Live Server extension.

## Before publishing
- Replace `YOUR_EMAIL@example.com` with your professional email.
- Add your phone number if you want it public.
- Replace placeholder GitHub profile links in each project card with the exact repository URLs.
- Replace the Netlify platform placeholder with the actual live URL for Nenu Na Cinema.
- Verify every project description and technology list. Remove anything not personally implemented.
- Confirm your current CGPA and education details.

## Publish with GitHub Pages
1. Create a new **public** GitHub repository named `goutham-portfolio`.
2. Upload `index.html`, `style.css`, `script.js` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish and copy the live URL shown in the Pages section.

You can also import the GitHub repository into Netlify and deploy it as a static site. No build command is required; publish directory is the repository root.

## Current stack
- HTML5
- CSS3
- Vanilla JavaScript

The portfolio does not claim React, TypeScript or advanced backend expertise.
